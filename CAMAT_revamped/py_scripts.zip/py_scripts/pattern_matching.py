"""Pattern matching and analysis utilities for binary matrix pattern search."""

from __future__ import annotations

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional, Tuple, Union

__all__ = [
    'resize_kernel',
    'summarize_best',
    'top_matches',
    'apply_threshold',
    'finite_bounds',
    'run_pattern_search',
]


def resize_kernel(arr: np.ndarray, scale_y: float, scale_x: float) -> np.ndarray:
    """
    Resize a kernel using bilinear interpolation.

    Parameters
    ----------
    arr : np.ndarray
        Input kernel array.
    scale_y : float
        Scaling factor for rows (vertical).
    scale_x : float
        Scaling factor for columns (horizontal).

    Returns
    -------
    np.ndarray
        Resized kernel array.
    """
    arr = np.asarray(arr, dtype=float)
    src_rows, src_cols = arr.shape
    tgt_rows = max(1, int(round(src_rows * scale_y)))
    tgt_cols = max(1, int(round(src_cols * scale_x)))

    if tgt_rows == src_rows and tgt_cols == src_cols:
        return arr.copy()

    y_grid = np.linspace(0, src_rows - 1, tgt_rows)
    x_grid = np.linspace(0, src_cols - 1, tgt_cols)
    y0 = np.floor(y_grid).astype(int)
    y1 = np.clip(y0 + 1, 0, src_rows - 1)
    wy = y_grid - y0
    x0 = np.floor(x_grid).astype(int)
    x1 = np.clip(x0 + 1, 0, src_cols - 1)
    wx = x_grid - x0

    top = (1 - wx) * arr[y0[:, None], x0] + wx * arr[y0[:, None], x1]
    bottom = (1 - wx) * arr[y1[:, None], x0] + wx * arr[y1[:, None], x1]
    return (1 - wy)[:, None] * top + wy[:, None] * bottom


def summarize_best(name: str, data: np.ndarray, labels_y: List[str], labels_x: List[str]) -> None:
    """
    Print the best match result for a given metric.

    Parameters
    ----------
    name : str
        Name of the metric.
    data : np.ndarray
        Metric data array.
    labels_y : list[str]
        Row labels.
    labels_x : list[str]
        Column labels.
    """
    finite_mask = np.isfinite(data)
    if not finite_mask.any():
        print(f'{name}: no finite values to summarise.')
        return

    flat_index = np.nanargmax(data)
    r, c = divmod(flat_index, data.shape[1])
    print(f'{name} best: {data[r, c]:.3f} at top-left (row={labels_y[r]}, col={labels_x[c]})')


def top_matches(
    name: str,
    data: np.ndarray,
    labels_y: List[str],
    labels_x: List[str],
    top_n: int,
    threshold: Optional[float] = None
) -> None:
    """
    Print the top N matches for a given metric.

    Parameters
    ----------
    name : str
        Name of the metric.
    data : np.ndarray
        Metric data array.
    labels_y : list[str]
        Row labels.
    labels_x : list[str]
        Column labels.
    top_n : int
        Number of top matches to report.
    threshold : float, optional
        Minimum threshold for reporting matches.
    """
    if top_n is None or top_n <= 0:
        return

    flat = data.reshape(-1)
    mask = np.isfinite(flat)
    if threshold is not None:
        mask &= flat >= threshold

    indices = np.nonzero(mask)[0]
    if indices.size == 0:
        print(f'{name}: no entries meet the threshold.')
        return

    ranked = indices[np.argsort(flat[indices])[::-1]]
    limit = min(top_n, ranked.size)
    print(f'{name} top {limit} positions:')

    for idx in ranked[:limit]:
        val = flat[idx]
        r, c = divmod(idx, data.shape[1])
        print(f'  score={val:.3f} at row={labels_y[r]}, col={labels_x[c]}')


def apply_threshold(data: np.ndarray, threshold: Optional[float]) -> np.ndarray:
    """
    Apply threshold to data, setting values below threshold to NaN.

    Parameters
    ----------
    data : np.ndarray
        Input data array.
    threshold : float, optional
        Threshold value. If None, returns data unchanged.

    Returns
    -------
    np.ndarray
        Thresholded data.
    """
    if threshold is None:
        return data
    return np.where(data >= threshold, data, np.nan)


def finite_bounds(data: np.ndarray) -> Tuple[float, float]:
    """
    Get the bounds of finite values in the data.

    Parameters
    ----------
    data : np.ndarray
        Input data array.

    Returns
    -------
    tuple[float, float]
        (low, high) bounds of finite values.
    """
    finite = data[np.isfinite(data)]
    if finite.size == 0:
        return 0.0, 1.0

    low = float(finite.min())
    high = float(finite.max())
    if low == high:
        high = low + 1e-9
    return low, high


def run_pattern_search(
    matrix_source: Union[np.ndarray, pd.DataFrame],
    kernel_candidate: Union[np.ndarray, pd.DataFrame],
    metrics: List[str] = None,
    stride_y: int = 1,
    stride_x: int = 1,
    kernel_scale_factors: List[float] = None,
    kernel_scale_axes: List[str] = None,
    binarize_scaled_kernel: bool = True,
    binarize_threshold: float = 0.5,
    top_n_matches: int = 20,
    plot_thresholds: Dict[str, Optional[float]] = None,
) -> Dict[str, Any]:
    """
    Run pattern search analysis on binary matrices.

    Parameters
    ----------
    matrix_source : np.ndarray or pd.DataFrame
        Source binary matrix to search in.
    kernel_candidate : np.ndarray or pd.DataFrame
        Kernel pattern to search for.
    metrics : list[str], optional
        Metrics to compute. Defaults to ['normalized_overlap'].
    stride_y : int, optional
        Step size along pitch axis. Default is 1.
    stride_x : int, optional
        Step size along time axis. Default is 1.
    kernel_scale_factors : list[float], optional
        Scale factors for kernel resizing. Default is [0.5, 0.75, 1.0, 1.5, 2.0].
    kernel_scale_axes : list[str], optional
        Axes to scale ('x', 'y', 'both'). Default is ['x'].
    binarize_scaled_kernel : bool, optional
        Whether to binarize scaled kernels. Default is True.
    binarize_threshold : float, optional
        Threshold for binarization. Default is 0.5.
    top_n_matches : int, optional
        Number of top matches to report. Default is 20.
    plot_thresholds : dict[str, float], optional
        Thresholds for plotting different metrics.

    Returns
    -------
    dict[str, Any]
        Dictionary containing results and metadata.
    """
    if metrics is None:
        metrics = ['normalized_overlap']

    if kernel_scale_factors is None:
        kernel_scale_factors = [0.5, 0.75, 1.0, 1.5, 2.0]

    if kernel_scale_axes is None:
        kernel_scale_axes = ['x']

    if plot_thresholds is None:
        plot_thresholds = {
            'normalized_overlap': 0,
            'cross_covariance': None,
            'normalized_cross_correlation': None,
        }

    # Convert inputs to numpy arrays
    if isinstance(matrix_source, pd.DataFrame):
        matrix = matrix_source.to_numpy(dtype=float)
        row_labels_full = list(matrix_source.index)
        col_labels_full = list(matrix_source.columns)
    else:
        matrix = np.asarray(matrix_source, dtype=float)
        if matrix.ndim != 2:
            raise ValueError('matrix_source must be a 2D table or array.')
        row_labels_full = list(range(matrix.shape[0]))
        col_labels_full = list(range(matrix.shape[1]))

    if isinstance(kernel_candidate, pd.DataFrame):
        kernel_array = kernel_candidate.to_numpy(dtype=float)
    else:
        kernel_array = np.asarray(kernel_candidate, dtype=float)

    if kernel_array.ndim != 2:
        raise ValueError('kernel_candidate must be a 2D structure to act as a kernel.')

    if kernel_array.size == 0:
        raise ValueError('kernel_candidate is empty; draw a pattern before running the analysis.')

    # Generate scale variants
    scale_variants = []
    seen_scales = set()
    for axis in kernel_scale_axes:
        axis_norm = axis.lower()
        if axis_norm not in {'x', 'y', 'both'}:
            raise ValueError(f'Unsupported axis {axis!r} in kernel_scale_axes; use "x", "y", or "both".')

        for factor in kernel_scale_factors:
            factor = float(factor)
            if factor <= 0:
                raise ValueError(f'Scale factor must be positive; received {factor}.')

            scale_y = factor if axis_norm in {'y', 'both'} else 1.0
            scale_x = factor if axis_norm in {'x', 'both'} else 1.0
            key = (round(scale_y, 6), round(scale_x, 6))

            if key in seen_scales:
                continue

            seen_scales.add(key)
            label = f'axis={axis_norm}, factor={factor:g}, scale_y={scale_y:.3f}, scale_x={scale_x:.3f}'
            scale_variants.append({
                'axis': axis_norm,
                'factor': factor,
                'scale_y': scale_y,
                'scale_x': scale_x,
                'label': label
            })

    print(f'Source matrix shape: {matrix.shape}')
    print(f'Base kernel shape: {kernel_array.shape}')
    print(f'Stride (Y, X): ({stride_y}, {stride_x})')
    print(f'Kernel scale variants to evaluate: {len(scale_variants)}')

    # Available metrics
    available_metrics = {
        'normalized_overlap': {'label': 'Normalised overlap'},
        'cross_covariance': {'label': 'Cross-covariance'},
        'normalized_cross_correlation': {'label': 'Normalised cross-correlation'},
    }

    selected_metrics = [m for m in metrics if m in available_metrics]
    if not selected_metrics:
        raise ValueError('No supported metrics selected.')

    print('Metrics to run:', ', '.join(available_metrics[m]['label'] for m in selected_metrics))

    # Process each scale variant
    all_results = {}
    scaled_kernels = {}
    last_variant_key = None
    last_conv_raw_df = None

    for variant in scale_variants:
        scale_y = variant['scale_y']
        scale_x = variant['scale_x']
        variant_key = variant['label']

        print(f'Processing {variant_key} -> shape={resize_kernel(kernel_array, scale_y, scale_x).shape}')

        scaled_kernel = resize_kernel(kernel_array, scale_y, scale_x)

        if binarize_scaled_kernel:
            scaled_kernel = (scaled_kernel >= binarize_threshold).astype(float)

        if scaled_kernel.shape[0] > matrix.shape[0] or scaled_kernel.shape[1] > matrix.shape[1]:
            print('  Skipped: scaled kernel is larger than the source matrix.')
            continue

        window_shape = scaled_kernel.shape
        out_rows = matrix.shape[0] - window_shape[0] + 1
        out_cols = matrix.shape[1] - window_shape[1] + 1

        if out_rows <= 0 or out_cols <= 0:
            print('  Skipped: kernel cannot slide within the source matrix.')
            continue

        windows = np.lib.stride_tricks.sliding_window_view(matrix, window_shape)
        conv_scores_full = (windows * scaled_kernel).sum(axis=(-2, -1))

        metric_arrays = {}
        metric_dfs = {}

        row_positions = list(range(0, out_rows, max(1, int(stride_y))))
        col_positions = list(range(0, out_cols, max(1, int(stride_x))))
        row_labels = [row_labels_full[pos] for pos in row_positions]
        col_labels = [col_labels_full[pos] for pos in col_positions]

        # Normalized overlap
        if 'normalized_overlap' in selected_metrics:
            kernel_weight = scaled_kernel.sum()
            if kernel_weight != 0:
                conv_norm_full = conv_scores_full / kernel_weight
            else:
                conv_norm_full = conv_scores_full.astype(float)

            conv_norm = conv_norm_full[np.ix_(row_positions, col_positions)]
            metric_arrays['normalized_overlap'] = conv_norm
            metric_dfs['normalized_overlap'] = pd.DataFrame(conv_norm, index=row_labels, columns=col_labels)
            conv_raw = conv_scores_full[np.ix_(row_positions, col_positions)]
            last_conv_raw_df = pd.DataFrame(conv_raw, index=row_labels, columns=col_labels)

        # Cross-covariance and normalized cross-correlation
        needs_cross = any(m in selected_metrics for m in ('cross_covariance', 'normalized_cross_correlation'))
        if needs_cross:
            windows_flat = windows.reshape(out_rows, out_cols, -1)
            kernel_flat = scaled_kernel.reshape(-1)
            kernel_mean = kernel_flat.mean()
            kernel_zero_mean = kernel_flat - kernel_mean
            kernel_norm_val = np.linalg.norm(kernel_zero_mean)

            window_means = windows_flat.mean(axis=2, keepdims=True)
            windows_zero_mean = windows_flat - window_means
            window_norms = np.linalg.norm(windows_zero_mean, axis=2)
            cross_cov_full = np.tensordot(windows_zero_mean, kernel_zero_mean, axes=([2], [0]))

            if 'cross_covariance' in selected_metrics:
                cross_cov = cross_cov_full[np.ix_(row_positions, col_positions)]
                metric_arrays['cross_covariance'] = cross_cov
                metric_dfs['cross_covariance'] = pd.DataFrame(cross_cov, index=row_labels, columns=col_labels)

            if 'normalized_cross_correlation' in selected_metrics:
                denominator = window_norms * kernel_norm_val
                norm_cross_full = np.divide(
                    cross_cov_full,
                    denominator,
                    out=np.zeros_like(cross_cov_full),
                    where=denominator > 0,
                )
                norm_cross = norm_cross_full[np.ix_(row_positions, col_positions)]
                metric_arrays['normalized_cross_correlation'] = norm_cross
                metric_dfs['normalized_cross_correlation'] = pd.DataFrame(norm_cross, index=row_labels, columns=col_labels)

        # Print results for this variant
        for metric_key in selected_metrics:
            metric_label = available_metrics[metric_key]['label']
            data = metric_arrays.get(metric_key)
            if data is not None:
                threshold = plot_thresholds.get(metric_key)
                summarize_best(metric_label, data, row_labels, col_labels)
                top_matches(metric_label, data, row_labels, col_labels, top_n_matches, threshold)

        all_results[variant_key] = metric_dfs
        scaled_kernels[variant_key] = scaled_kernel
        last_variant_key = variant_key

    # Prepare final results
    results = {
        'pattern_search_results': all_results,
        'pattern_search_kernels': scaled_kernels,
        'last_pattern_search_variant': last_variant_key,
        'last_conv_raw_df': last_conv_raw_df,
        'row_labels_full': row_labels_full,
        'col_labels_full': col_labels_full,
    }

    if last_variant_key is not None:
        last_metrics = all_results[last_variant_key]
        results.update({
            'conv_norm_df': last_metrics.get('normalized_overlap'),
            'cross_cov_df': last_metrics.get('cross_covariance'),
            'norm_cross_df': last_metrics.get('normalized_cross_correlation'),
        })
    else:
        results.update({
            'conv_norm_df': None,
            'cross_cov_df': None,
            'norm_cross_df': None,
        })

    print('Stored results in pattern_search_results; last variant key:', last_variant_key)
    return results
