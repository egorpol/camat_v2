"""Configuration constants for pattern matching analysis."""

from __future__ import annotations

# Stride settings
STRIDE_Y: int = 1  # step along pitch axis (rows); increase to prefer octave/tonality jumps
STRIDE_X: int = 1  # step along time axis (columns)

# Reporting settings
TOP_N_MATCHES: int = 20  # number of highest-scoring positions to report per metric

# Plotting thresholds
PLOT_THRESHOLDS: dict[str, float | None] = {
    'normalized_overlap': 0,  # e.g., 0.6 to keep only strong overlaps
    'cross_covariance': None,
    'normalized_cross_correlation': None,
}

# Kernel scaling settings
KERNEL_SCALE_FACTORS: list[float] = [0.5, 0.75, 1.0, 1.5, 2.0]  # e.g., [0.5, 0.75, 1.0, 1.5, 2.0]
KERNEL_SCALE_AXES: list[str] = ['x']  # options: 'x', 'y', 'both'

# Plotting settings
PLOT_SCALED_KERNELS: bool = False
BINARIZE_SCALED_KERNEL: bool = True  # If True, threshold scaled kernels to {0,1}
BINARIZE_THRESHOLD: float = 0.5  # Threshold used when binarizing scaled kernels
SHARE_Y_SCALING: bool = True  # Share colorbar scaling across plots when multiple scale factors are used

# Matplotlib colormap
MPL_CMAP: str = 'viridis'

# Available metrics
AVAILABLE_METRICS: dict[str, dict[str, str]] = {
    'normalized_overlap': {'label': 'Normalised overlap'},
    'cross_covariance': {'label': 'Cross-covariance'},
    'normalized_cross_correlation': {'label': 'Normalised cross-correlation'},
}

# Default metrics to run
DEFAULT_METRICS: list[str] = ['normalized_overlap']  # 'normalized_overlap', 'cross_covariance', 'normalized_cross_correlation'

__all__ = [
    'STRIDE_Y',
    'STRIDE_X',
    'TOP_N_MATCHES',
    'PLOT_THRESHOLDS',
    'KERNEL_SCALE_FACTORS',
    'KERNEL_SCALE_AXES',
    'PLOT_SCALED_KERNELS',
    'BINARIZE_SCALED_KERNEL',
    'BINARIZE_THRESHOLD',
    'SHARE_Y_SCALING',
    'MPL_CMAP',
    'AVAILABLE_METRICS',
    'DEFAULT_METRICS',
]
