"""Plotting utilities for pattern matching results."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from typing import Optional, Tuple, Dict, Any

try:
    from bokeh.io import output_notebook
    from bokeh.plotting import figure, show
    from bokeh.models import LinearColorMapper, ColorBar
    from bokeh.palettes import Viridis256
    BOKEH_AVAILABLE = True
except ImportError:
    BOKEH_AVAILABLE = False

from pattern_matching import apply_threshold, finite_bounds

__all__ = [
    'set_plotting_backend',
    'plot_matplotlib_single',
    'plot_bokeh_single',
    'plot_kernel',
]


# Global backend setting
PLOTTING_BACKEND = 'plt'


def set_plotting_backend(backend: str) -> None:
    """
    Set the global plotting backend.

    Parameters
    ----------
    backend : str
        Plotting backend to use ('plt', 'bokeh', 'both', 'none').
    """
    global PLOTTING_BACKEND
    if backend not in ('plt', 'bokeh', 'both', 'none'):
        raise ValueError(f"Unknown backend {backend!r}. Available options: 'plt', 'bokeh', 'both', 'none'.")
    PLOTTING_BACKEND = backend


def plot_matplotlib_single(
    title: str,
    data: np.ndarray,
    threshold: Optional[float] = None,
    color_bounds: Optional[Tuple[float, float]] = None
) -> None:
    """
    Plot data using matplotlib.

    Parameters
    ----------
    title : str
        Plot title.
    data : np.ndarray
        Data to plot.
    threshold : float, optional
        Threshold for masking data.
    color_bounds : tuple[float, float], optional
        Color scale bounds (vmin, vmax).
    """
    fig, ax = plt.subplots(figsize=(9, 6))
    masked = apply_threshold(data, threshold)

    if color_bounds is None:
        vmin, vmax = None, None
    else:
        vmin, vmax = color_bounds

    im = ax.imshow(masked, cmap='viridis', origin='upper', aspect='auto', vmin=vmin, vmax=vmax)
    ax.set_title(title)
    ax.set_xlabel('time offset (columns)')
    ax.set_ylabel('pitch offset (rows)')
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.show()


def plot_bokeh_single(
    title: str,
    data: np.ndarray,
    threshold: Optional[float] = None,
    color_bounds: Optional[Tuple[float, float]] = None
) -> None:
    """
    Plot data using bokeh.

    Parameters
    ----------
    title : str
        Plot title.
    data : np.ndarray
        Data to plot.
    threshold : float, optional
        Threshold for masking data.
    color_bounds : tuple[float, float], optional
        Color scale bounds (low, high).
    """
    if not BOKEH_AVAILABLE:
        print("Bokeh is not available. Install bokeh to use bokeh plotting.")
        return

    masked = apply_threshold(data, threshold)

    if color_bounds is None:
        low, high = finite_bounds(masked)
    else:
        low, high = color_bounds

    fig = figure(
        title=title,
        x_range=(0, masked.shape[1]),
        y_range=(0, masked.shape[0]),
        width=900,
        height=600,
        tools='pan,wheel_zoom,reset,save',
    )

    mapper = LinearColorMapper(palette=Viridis256, low=low, high=high)
    fig.image(image=[np.flipud(masked)], x=0, y=0, dw=masked.shape[1], dh=masked.shape[0], color_mapper=mapper)
    fig.add_layout(ColorBar(color_mapper=mapper), 'right')
    fig.xaxis.axis_label = 'time offset (columns)'
    fig.yaxis.axis_label = 'pitch offset (rows, top=high)'
    show(fig)


def plot_kernel(title: str, kernel: np.ndarray) -> None:
    """
    Plot a kernel using the configured backend.

    Parameters
    ----------
    title : str
        Plot title.
    kernel : np.ndarray
        Kernel data to plot.
    """
    if PLOTTING_BACKEND in ('plt', 'both'):
        fig, ax = plt.subplots(figsize=(9, 6))
        im = ax.imshow(kernel, cmap='viridis', origin='upper', aspect='auto')
        ax.set_title(title)
        ax.set_xlabel('kernel columns')
        ax.set_ylabel('kernel rows')
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        plt.show()

    if PLOTTING_BACKEND in ('bokeh', 'both'):
        if not BOKEH_AVAILABLE:
            print("Bokeh is not available. Install bokeh to use bokeh plotting.")
            return

        low, high = finite_bounds(kernel)
        fig = figure(
            title=title,
            x_range=(0, kernel.shape[1]),
            y_range=(0, kernel.shape[0]),
            width=900,
            height=600,
            tools='pan,wheel_zoom,reset,save',
        )
        mapper = LinearColorMapper(palette=Viridis256, low=low, high=high)
        fig.image(image=[np.flipud(kernel)], x=0, y=0, dw=kernel.shape[1], dh=kernel.shape[0], color_mapper=mapper)
        fig.add_layout(ColorBar(color_mapper=mapper), 'right')
        fig.xaxis.axis_label = 'kernel columns'
        fig.yaxis.axis_label = 'kernel rows (top=high)'
        show(fig)


def plot_pattern_results(
    results: Dict[str, Any],
    plot_scaled_kernels: bool = False,
    share_y_scaling: bool = True,
    backend: str = 'plt'
) -> None:
    """
    Plot pattern search results with shared color scaling if requested.

    Parameters
    ----------
    results : dict[str, Any]
        Results dictionary from run_pattern_search.
    plot_scaled_kernels : bool, optional
        Whether to plot scaled kernels. Default is False.
    share_y_scaling : bool, optional
        Whether to share colorbar scaling across plots. Default is True.
    backend : str, optional
        Plotting backend to use. Default is 'plt'.
    """
    set_plotting_backend(backend)

    pattern_search_results = results.get('pattern_search_results', {})
    pattern_search_kernels = results.get('pattern_search_kernels', {})

    if not pattern_search_results:
        print("No pattern search results to plot.")
        return

    # Storage for global color bounds when sharing is enabled
    shared_bounds = {}
    deferred_plots = []

    # First pass: collect bounds if sharing is enabled
    if share_y_scaling and len(pattern_search_results) > 1:
        for variant_key, metrics in pattern_search_results.items():
            for metric_key, df in metrics.items():
                if metric_key not in shared_bounds:
                    shared_bounds[metric_key] = [np.inf, -np.inf]

                data = df.to_numpy()
                masked = apply_threshold(data, None)  # No threshold for bounds calculation

                if np.isfinite(masked).any():
                    low, high = finite_bounds(masked)
                    bounds = shared_bounds[metric_key]
                    bounds[0] = min(bounds[0], low)
                    bounds[1] = max(bounds[1], high)

        # Finalize bounds
        for metric_key, (lo, hi) in shared_bounds.items():
            if np.isfinite(lo) and np.isfinite(hi) and lo < hi:
                shared_bounds[metric_key] = (lo, hi)

    # Plot results
    for variant_key, metrics in pattern_search_results.items():
        print(f"\n--- Results for {variant_key} ---")

        for metric_key, df in metrics.items():
            data = df.to_numpy()
            threshold = None  # Could be made configurable

            if share_y_scaling and len(pattern_search_results) > 1:
                color_bounds = shared_bounds.get(metric_key)
                deferred_plots.append({
                    'metric_key': metric_key,
                    'data': data,
                    'threshold': threshold,
                    'color_bounds': color_bounds,
                    'row_labels': list(df.index),
                    'col_labels': list(df.columns),
                })
            else:
                # Plot immediately
                if backend == 'plt':
                    plot_matplotlib_single(f"{AVAILABLE_METRICS[metric_key]['label']} - {variant_key}", data, threshold=threshold, color_bounds=None)
                elif backend == 'bokeh':
                    plot_bokeh_single(f"{AVAILABLE_METRICS[metric_key]['label']} - {variant_key}", data, threshold=threshold, color_bounds=None)
                elif backend == 'both':
                    plot_matplotlib_single(f"{AVAILABLE_METRICS[metric_key]['label']} - {variant_key}", data, threshold=threshold, color_bounds=None)
                    plot_bokeh_single(f"{AVAILABLE_METRICS[metric_key]['label']} - {variant_key}", data, threshold=threshold, color_bounds=None)

        # Plot scaled kernel if requested
        if plot_scaled_kernels and variant_key in pattern_search_kernels:
            kernel = pattern_search_kernels[variant_key]
            plot_kernel(f'Scaled kernel - {variant_key}', kernel)

    # Render deferred plots with shared color scale if requested
    if share_y_scaling and len(pattern_search_results) > 1 and deferred_plots:
        print(f"\n--- Shared Color Scale Plots ---")
        for item in deferred_plots:
            metric_key = item['metric_key']
            data = item['data']
            threshold = item['threshold']
            color_bounds = item['color_bounds']

            if backend == 'plt':
                plot_matplotlib_single(f"{AVAILABLE_METRICS[metric_key]['label']}", data, threshold=threshold, color_bounds=color_bounds)
            elif backend == 'bokeh':
                plot_bokeh_single(f"{AVAILABLE_METRICS[metric_key]['label']}", data, threshold=threshold, color_bounds=color_bounds)
            elif backend == 'both':
                plot_matplotlib_single(f"{AVAILABLE_METRICS[metric_key]['label']}", data, threshold=threshold, color_bounds=color_bounds)
                plot_bokeh_single(f"{AVAILABLE_METRICS[metric_key]['label']}", data, threshold=threshold, color_bounds=color_bounds)


# Available metrics for reference
AVAILABLE_METRICS = {
    'normalized_overlap': {'label': 'Normalised overlap'},
    'cross_covariance': {'label': 'Cross-covariance'},
    'normalized_cross_correlation': {'label': 'Normalised cross-correlation'},
}
